// import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.*;
// import org.junit.jupiter.api.Test;

// convert the pattern to a String and take the substring to compare values

public class Main {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    boolean notStarted = true;
    if(notStarted){
      System.out.println("Welcome to the game of Simon!");
      System.out.println("Type out the numbers you see light up as a string.");
      notStarted = false;
      String start = "";
      while(!(start.equalsIgnoreCase("Start"))){
        System.out.println("Type 'Start' to begin.");
        start = input.nextLine();
      }
    }
    int score = 0;
    
    ArrayList<Integer> pattern = new ArrayList<Integer>();
    String[][] grid = new String[16][18];
    for(int i = 0; i < 16; i++){
      grid[i][0] = "  ";
      grid[i][17] = "  ";
    }

    grid[0][0] = "1)";
    grid[15][0] = "3)";
    grid[0][17] = "(2";
    grid[15][17] = "(4";
    for(int r = 0; r < grid.length; r++){
        for(int c = 1; c < grid[0].length-1; c++){
            grid[r][c] = "- ";
        }
    }
    if(notStarted){
      for(int r = 0; r < grid.length; r++){
        for(int c = 0; c < grid[0].length; c++){
            System.out.print(grid[r][c]);
        }
      System.out.println();
    }
    }
    
    boolean gameOn = true;

    while(gameOn){

      int newObject = (int)(Math.random()*4+1);
      //System.out.println("TEST");
      
      pattern.add(newObject);
      //pattern being shown on screen
      for(int i = 0; i < pattern.size(); i++){
        if(pattern.get(i) == 1){

          clearScreen();
          for(int r = 0; r < 8; r++){
            for(int c = 1; c < 9; c++){
              grid[r][c] = "0 ";
            }
          }

          for(int r = 0; r < grid.length; r++){
              for(int c = 0; c < grid[0].length; c++){

                  System.out.print(grid[r][c]);
              }
            System.out.println();
          }
          
          try {
            Thread.sleep(1500);
          } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
          }
          clearScreen();
          for(int r = 0; r < grid.length; r++){
              for(int c = 1; c < grid[0].length-1; c++){
                grid[r][c] = "- ";
                System.out.print(grid[r][c]);
              }
            System.out.println();
          }
          
        }
        else if(pattern.get(i) == 2){
  
          
          clearScreen();
          for(int r = 0; r < 8; r++){
            for(int c = 8; c < 17; c++){
              grid[r][c] = "0 ";
            }
          }
          for(int r = 0; r < grid.length; r++){
              for(int c = 0; c < grid[0].length; c++){
 
                  System.out.print(grid[r][c]);
              }
            System.out.println();
          }
          
          try {
            Thread.sleep(1500);
          } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
          }
          clearScreen();
          for(int r = 0; r < grid.length; r++){
              for(int c = 1; c < grid[0].length-1; c++){
                grid[r][c] = "- ";
                System.out.print(grid[r][c]);
              }
            System.out.println();
          }
          
        }
        else if(pattern.get(i) == 3){

          clearScreen();
          for(int r = 8; r < 16; r++){
            for(int c = 1; c < 9; c++){
              grid[r][c] = "0 ";
            }
          }

          for(int r = 0; r < grid.length; r++){
              for(int c = 0; c < grid[0].length; c++){

                  System.out.print(grid[r][c]);
              }
            System.out.println();
          }
          
          try {
            Thread.sleep(1500);
          } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
          }
          clearScreen();
          for(int r = 0; r < grid.length; r++){
              for(int c = 1; c < grid[0].length-1; c++){
                grid[r][c] = "- ";
                System.out.print(grid[r][c]);
              }
            System.out.println();
          }
          
        }
        else{

          clearScreen();
          for(int r = 8; r < 16; r++){
            for(int c = 8; c < 17; c++){
              grid[r][c] = "0 ";
            }
          }

          for(int r = 0; r < grid.length; r++){
              for(int c = 0; c < grid[0].length-1; c++){

                  System.out.print(grid[r][c]);
              }
            System.out.println();
          }
          
          try {
            Thread.sleep(1500);
          } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
          }
          clearScreen();
          for(int r = 0; r < grid.length; r++){
              for(int c = 1; c < grid[0].length-1; c++){
                grid[r][c] = "- ";
                System.out.print(grid[r][c]);
              }
            System.out.println();
          }
          
        }
      }
      
      clearScreen();
      for(int r = 0; r < grid.length; r++){
          for(int c = 0; c < grid[0].length; c++){

              System.out.print(grid[r][c]);
          }
        System.out.println();
      }
      try {
        Thread.sleep(1500);
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
      }
      
      System.out.println("What was the pattern?");
      int guess = input.nextInt();
      for(int i = pattern.size()-1; i >=0; i--){
        if(!((int)(guess % 10) == pattern.get(i))){
          gameOn = false;
        }
        guess /= 10;

      }
      score++;
    }
    System.out.println("GAME OVER");
    System.out.println("You achieved a score of " + score);
    
  }
  public static void clearScreen() {  
      System.out.print("\033[H\033[2J");  
      System.out.flush();  
  }  
  public static void sleep(long ms) throws InterruptedException
  {
  sleep(ms);
  }
}